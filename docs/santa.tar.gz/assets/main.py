#!/usr/bin/env python3
"""Santa's Rooftop Run: a keyboard-controlled driving and resource-management game."""
"""# Copyright (C) 2026 Daniel Slowik
# SPDX-License-Identifier: AGPL-3.0-only
#
# This program is free software under the GNU Affero General Public License
# version 3 only. See the LICENSE file for details.
"""

"""
Santa's Rooftop Run

Controls:
    I or Up Arrow    - Fly up
    J or Left Arrow  - Fly left
    K or Down Arrow  - Fly down
    L or Right Arrow - Fly right
    1-5              - Choose starting difficulty on title screen
    Enter or Space   - Start at difficulty 1
    H                - Open instructions from title screen
    B or Backspace   - Return to title from instructions
    R                - Restart after game over
    Escape           - Quit

Gameplay:
    Land with the whole sleigh on a rooftop to make a delivery and earn points.
    A partial rooftop landing or house collision counts as a crash.
    Ten house crashes end the game. Any aircraft collision ends the game.
    Collect milk and cookies; they become bonus points when you land.
    Storm clouds cost points.
    Difficulty increases every three successful deliveries, up to level 5.

Audio files:
    assets/flying.ogg - looping flight sound
    assets/crash.ogg  - house/aircraft crash sound
    assets/bonus.ogg  - milk/cookie pickup and successful landing sound

Run locally:
    python3 -m pip install pygame-ce
    python3 main.py

Run in a browser with Pygbag:
    From the directory containing the SANTA folder, run:
    python3 -m pip install pygbag
    python3 -m pygbag SANTA
"""

import asyncio
import random
import sys
from pathlib import Path

import pygame


WIDTH = 960
HEIGHT = 540
FPS = 60
CRASH_LIMIT = 10

SKY = (13, 24, 58)
WHITE = (245, 248, 255)
GOLD = (255, 205, 70)
RED = (210, 48, 65)
PALE_BLUE = (190, 220, 255)

LEVEL_NAMES = [
    "Gentle",
    "Breezy",
    "Windy",
    "Stormy",
    "Blizzard",
]


def clamp(value, minimum, maximum):
    """Keep value between minimum and maximum."""
    return max(minimum, min(maximum, value))


def object_rect(obj):
    """Create a Pygame rectangle from an object's position and size."""
    return pygame.Rect(
        round(obj["x"]),
        round(obj["y"]),
        obj["w"],
        obj["h"],
    )


def draw_text(surface, font, text, x, y, color=WHITE):
    """Draw text at the given screen position."""
    image = font.render(text, True, color)
    surface.blit(image, (x, y))


def draw_sleigh(surface, rect):
    """Draw Santa and his sleigh using simple shapes."""
    # Sleigh body and runner
    pygame.draw.ellipse(
        surface,
        RED,
        (rect.x + 5, rect.y + 15, 49, 16),
    )
    pygame.draw.arc(
        surface,
        GOLD,
        (rect.x + 4, rect.y + 20, 52, 18),
        0,
        3.14,
        3,
    )
    pygame.draw.line(
        surface,
        GOLD,
        (rect.x + 10, rect.bottom - 1),
        (rect.x + 55, rect.bottom - 1),
        3,
    )

    # Santa's face, hat, and pom-pom
    pygame.draw.circle(
        surface,
        (240, 190, 155),
        (rect.x + 34, rect.y + 10),
        9,
    )
    pygame.draw.circle(
        surface,
        RED,
        (rect.x + 34, rect.y + 4),
        9,
    )
    pygame.draw.polygon(
        surface,
        WHITE,
        [
            (rect.x + 25, rect.y + 4),
            (rect.x + 42, rect.y + 4),
            (rect.x + 34, rect.y - 4),
        ],
    )
    pygame.draw.circle(
        surface,
        GOLD,
        (rect.x + 5, rect.y + 16),
        3,
    )


def draw_house(surface, house):
    """Draw a house, peaked roof, and lit windows."""
    x = round(house["x"])
    y = round(house["y"])
    width = house["w"]
    height = house["h"]

    house_colors = [
        (111, 76, 111),
        (82, 105, 143),
        (133, 86, 71),
        (89, 122, 103),
    ]
    color = house_colors[house["color"] % len(house_colors)]

    pygame.draw.rect(surface, color, (x, y, width, height))

    # Peaked roof with snow
    peak = (x + width // 2, y - 25)
    left_eave = (x - 5, y + 5)
    right_eave = (x + width + 5, y + 5)

    pygame.draw.polygon(
        surface,
        (55, 49, 75),
        [left_eave, peak, right_eave],
    )
    pygame.draw.line(surface, WHITE, left_eave, peak, 3)
    pygame.draw.line(surface, WHITE, peak, right_eave, 3)

    # Windows
    for window_x in (x + 14, x + width - 29):
        pygame.draw.rect(
            surface,
            GOLD,
            (window_x, y + 25, 15, 19),
        )
        pygame.draw.line(
            surface,
            color,
            (window_x + 7, y + 25),
            (window_x + 7, y + 44),
            2,
        )


def draw_cloud(surface, cloud):
    """Draw a storm cloud."""
    rect = object_rect(cloud)
    cloud_color = (130, 145, 170)

    pygame.draw.circle(
        surface, cloud_color, (rect.x + 24, rect.y + 25), 24
    )
    pygame.draw.circle(
        surface, cloud_color, (rect.x + 48, rect.y + 15), 29
    )
    pygame.draw.circle(
        surface, cloud_color, (rect.x + 72, rect.y + 25), 23
    )


def draw_plane(surface, plane):
    """Draw an aircraft."""
    rect = object_rect(plane)
    points = [
        (rect.x, rect.y + 12),
        (rect.x + 48, rect.y + 12),
        (rect.x + 70, rect.y + 3),
        (rect.x + 62, rect.y + 16),
        (rect.x + 70, rect.y + 27),
        (rect.x + 47, rect.y + 19),
        (rect.x, rect.y + 19),
    ]
    pygame.draw.polygon(surface, (220, 225, 235), points)


def draw_bonus(surface, bonus):
    """Draw a milk carton or cookie."""
    rect = object_rect(bonus)

    if bonus["kind"] == "milk":
        pygame.draw.rect(surface, WHITE, rect)
        pygame.draw.rect(
            surface,
            (90, 160, 230),
            (rect.x + 4, rect.y + 12, rect.w - 8, 5),
        )
    else:
        pygame.draw.circle(surface, (190, 115, 55), rect.center, 14)
        for dx, dy in ((-5, -4), (5, -6), (2, 5)):
            pygame.draw.circle(
                surface,
                (70, 45, 35),
                (rect.centerx + dx, rect.centery + dy),
                2,
            )


def load_sound(path, volume=1.0):
    """Load a sound effect, or return None if unavailable."""
    try:
        sound = pygame.mixer.Sound(str(path))
        sound.set_volume(volume)
        return sound
    except (pygame.error, OSError) as error:
        print(f"Could not load sound {path}: {error}")
        return None


def play_sound(sound):
    """Play a sound effect if it loaded successfully."""
    if sound is not None:
        sound.play()


def make_game(starting_level):
    """Create a fresh game state."""
    return {
        "starting_level": starting_level,
        "level": starting_level,
        "score": 0,
        "milk": 0,
        "cookies": 0,
        "deliveries": 0,
        "crashes": 0,
        "player": pygame.Rect(145, 190, 62, 38),
        "vertical_speed": 0.0,
        "houses": [],
        "clouds": [],
        "planes": [],
        "bonuses": [],
        "house_countdown": 250,
        "cloud_countdown": 180,
        "plane_countdown": 1300,
        "bonus_countdown": 500,
        "scroll": 0.0,
        "house_hit_cooldown": 0,
    }


async def main():
    """Initialize and run the game."""
    pygame.mixer.pre_init(44100, -16, 2, 1024)
    pygame.init()

    # Enlarge the Pygbag browser canvas while preserving the game's 16:9 ratio.
    if sys.platform == "emscripten":
        import platform

        canvas = platform.window.canvas
        canvas.style.width = "min(100vw, 177.78vh)"
        canvas.style.height = "min(56.25vw, 100vh)"
        canvas.style.display = "block"
        canvas.style.margin = "auto"

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Santa's Rooftop Run")

    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 28)
    small_font = pygame.font.Font(None, 22)
    big_font = pygame.font.Font(None, 58)

    # Keep the sounds inside the project so Pygbag can package them.
    asset_dir = Path(__file__).resolve().parent / "assets"
    crash_sound = load_sound(asset_dir / "crash.ogg", 0.8)
    bonus_sound = load_sound(asset_dir / "bonus.ogg", 0.8)

    music_loaded = False
    if pygame.mixer.get_init() is not None:
        try:
            pygame.mixer.music.load(str(asset_dir / "flying.ogg"))
            pygame.mixer.music.set_volume(0.35)
            music_loaded = True
        except (pygame.error, OSError) as error:
            print(f"Could not load flight music: {error}")

    state = "title"
    game = None
    running = True

    def start_flight_music():
        """Start the looping flight sound, if it loaded."""
        if music_loaded and not pygame.mixer.music.get_busy():
            pygame.mixer.music.play(-1)

    def begin_game(starting_level):
        """Start a fresh game and begin the flight music."""
        nonlocal game, state
        game = make_game(starting_level)
        state = "playing"
        start_flight_music()

    while running:
        clock.tick(FPS)

        # Handle start, restart, instructions, and quit keys.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

                if state == "title":
                    if pygame.K_1 <= event.key <= pygame.K_5:
                        chosen_level = event.key - pygame.K_1 + 1
                        begin_game(chosen_level)
                    elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        begin_game(1)
                    elif event.key == pygame.K_h:
                        state = "instructions"

                elif state == "instructions":
                    if event.key in (
                        pygame.K_b,
                        pygame.K_BACKSPACE,
                        pygame.K_RETURN,
                        pygame.K_SPACE,
                    ):
                        state = "title"

                elif state == "gameover" and event.key == pygame.K_r:
                    begin_game(1)

        screen.fill(SKY)

        # Stars move more slowly than the game world.
        scroll = game["scroll"] if game else 0
        for index in range(55):
            star_x = (index * 179 - int(scroll * 0.35)) % WIDTH
            star_y = (index * 83 + 17) % 300
            pygame.draw.circle(
                screen,
                (160, 180, 220),
                (star_x, star_y),
                1 + (index % 2),
            )

        if state == "title":
            draw_text(
                screen,
                big_font,
                "Santa's Rooftop Run",
                250,
                125,
                GOLD,
            )
            draw_text(
                screen,
                font,
                "Make rooftop deliveries, dodge storm clouds and aircraft,",
                210,
                215,
            )
            draw_text(
                screen,
                font,
                "and land safely to earn points.",
                330,
                248,
            )
            draw_text(
                screen,
                font,
                "Press 1-5 to choose difficulty, or Enter for level 1.",
                255,
                310,
                PALE_BLUE,
            )
            draw_text(
                screen,
                small_font,
                "Steer with I/J/K/L or the arrow keys. Escape quits.",
                295,
                355,
            )
            draw_text(
                screen,
                small_font,
                "Press H for instructions.",
                390,
                390,
                GOLD,
            )

        elif state == "instructions":
            draw_text(
                screen,
                big_font,
                "How to Play",
                365,
                55,
                GOLD,
            )
            draw_text(
                screen,
                font,
                "Land only when the whole sleigh fits on the rooftop.",
                205,
                130,
            )
            draw_text(
                screen,
                font,
                "Successful deliveries earn 100 points and play a bonus sound.",
                195,
                165,
            )
            draw_text(
                screen,
                font,
                "Partial rooftop landings and house hits count as crashes.",
                195,
                200,
            )
            draw_text(
                screen,
                font,
                "Collect milk and cookies; they become bonus points when you land.",
                145,
                235,
            )
            draw_text(
                screen,
                font,
                "Storm clouds cost 15 points. Aircraft collisions end the game.",
                175,
                270,
            )
            draw_text(
                screen,
                font,
                "10 house crashes end the game.",
                345,
                305,
                PALE_BLUE,
            )
            draw_text(
                screen,
                font,
                "CONTROLS",
                415,
                350,
                GOLD,
            )
            draw_text(
                screen,
                small_font,
                "Fly: I / Up, J / Left, K / Down, L / Right (or arrow keys)",
                300,
                385,
            )
            draw_text(
                screen,
                small_font,
                "Title: 1-5 choose difficulty; Enter/Space starts; H opens this page",
                205,
                415,
            )
            draw_text(
                screen,
                small_font,
                "Game over: R restarts. Escape quits.",
                335,
                445,
            )
            draw_text(
                screen,
                small_font,
                "Press B, Backspace, Enter, or Space to return to the menu.",
                250,
                490,
                PALE_BLUE,
            )

        elif state == "playing":
            player = game["player"]

            # Difficulty increases every three successful deliveries.
            game["level"] = min(
                5,
                game["starting_level"] + game["deliveries"] // 3,
            )
            level = game["level"]
            world_speed = 2.4 + level * 0.55
            game["scroll"] += world_speed

            # Spawn a rooftop ahead of the sleigh.
            game["house_countdown"] -= world_speed
            if game["house_countdown"] <= 0:
                roof_y = random.randint(270, 390)
                house_width = random.randint(100, 145)
                game["houses"].append({
                    "x": float(WIDTH + 100),
                    "y": roof_y,
                    "w": house_width,
                    "h": HEIGHT - roof_y,
                    "color": random.randrange(4),
                    "delivered": False,
                })
                game["house_countdown"] = random.randint(440, 680)

            # Spawn a storm cloud.
            game["cloud_countdown"] -= world_speed
            if game["cloud_countdown"] <= 0:
                game["clouds"].append({
                    "x": float(WIDTH + 90),
                    "y": random.randint(75, 300),
                    "w": random.randint(75, 115),
                    "h": random.randint(42, 60),
                })
                game["cloud_countdown"] = random.randint(
                    max(170, 420 - level * 35),
                    max(250, 560 - level * 35),
                )

            # Spawn an aircraft.
            game["plane_countdown"] -= world_speed
            if game["plane_countdown"] <= 0:
                game["planes"].append({
                    "x": float(WIDTH + 100),
                    "y": random.randint(80, 330),
                    "w": 72,
                    "h": 30,
                })
                game["plane_countdown"] = random.randint(
                    max(650, 1900 - level * 150),
                    max(900, 2600 - level * 150),
                )

            # Spawn milk or cookies.
            game["bonus_countdown"] -= world_speed
            if game["bonus_countdown"] <= 0:
                game["bonuses"].append({
                    "x": float(WIDTH + 100),
                    "y": random.randint(130, 350),
                    "w": 30,
                    "h": 30,
                    "kind": random.choice(("milk", "cookie")),
                })
                game["bonus_countdown"] = random.randint(550, 900)

            # Move world objects toward the left.
            for collection_name in ("houses", "clouds", "planes", "bonuses"):
                for obj in game[collection_name]:
                    obj["x"] -= world_speed

            # Poll the keyboard each frame so either key set works.
            keys = pygame.key.get_pressed()

            if keys[pygame.K_LEFT] or keys[pygame.K_j]:
                player.x -= 4
            if keys[pygame.K_RIGHT] or keys[pygame.K_l]:
                player.x += 4
            if keys[pygame.K_UP] or keys[pygame.K_i]:
                game["vertical_speed"] -= 0.48
            if keys[pygame.K_DOWN] or keys[pygame.K_k]:
                game["vertical_speed"] += 0.45

            # Gravity and vertical movement.
            old_bottom = player.bottom
            game["vertical_speed"] += 0.20
            game["vertical_speed"] = clamp(
                game["vertical_speed"],
                -5.5,
                5.5,
            )
            player.y += round(game["vertical_speed"])

            player.x = clamp(player.x, 15, WIDTH - player.width - 15)
            player.y = clamp(player.y, 20, HEIGHT - player.height - 15)

            # Storm clouds subtract points once when hit.
            for cloud in game["clouds"][:]:
                draw_cloud(screen, cloud)
                if player.colliderect(object_rect(cloud)):
                    game["score"] = max(0, game["score"] - 15)
                    game["clouds"].remove(cloud)

            # Any aircraft collision ends the game immediately.
            for plane in game["planes"][:]:
                draw_plane(screen, plane)
                if player.colliderect(object_rect(plane)):
                    game["crashes"] += 1
                    state = "gameover"

                    if music_loaded:
                        pygame.mixer.music.stop()

                    play_sound(crash_sound)
                    break

            # Show game over immediately after an aircraft collision.
            if state == "gameover":
                draw_sleigh(screen, player)
                draw_text(screen, big_font, "Sleigh crash!", 345, 150, RED)
                draw_text(
                    screen,
                    font,
                    f"Final score: {game['score']}",
                    395,
                    235,
                    GOLD,
                )
                draw_text(
                    screen,
                    font,
                    f"Rooftop deliveries: {game['deliveries']}",
                    355,
                    275,
                )
                draw_text(
                    screen,
                    font,
                    f"Crashes: {game['crashes']}/{CRASH_LIMIT}",
                    395,
                    310,
                    PALE_BLUE,
                )
                draw_text(
                    screen,
                    font,
                    "Press R to fly again.",
                    385,
                    350,
                    PALE_BLUE,
                )
                pygame.display.flip()
                await asyncio.sleep(0)
                continue

            # Check rooftop landings and house collisions.
            for house in game["houses"][:]:
                draw_house(screen, house)

                # Use the top edge of the house as the landing surface.
                roof_y = round(house["y"])
                roof = pygame.Rect(
                    round(house["x"]) - 5,
                    roof_y,
                    house["w"] + 10,
                    8,
                )

                landing_contact = (
                    not house["delivered"]
                    and game["vertical_speed"] > 0
                    and old_bottom <= roof_y
                    and player.bottom >= roof_y
                    and player.right > roof.left
                    and player.left < roof.right
                )

                if landing_contact:
                    player.bottom = roof_y

                    # The entire sleigh must fit within the roof edges.
                    fully_on_roof = (
                        player.left >= roof.left
                        and player.right <= roof.right
                    )

                    if fully_on_roof:
                        game["vertical_speed"] = -5.2
                        house["delivered"] = True
                        game["deliveries"] += 1
                        game["score"] += 100

                        # Convert collected treats to points on landing.
                        game["score"] += game["milk"] * 20
                        game["score"] += game["cookies"] * 20
                        game["milk"] = 0
                        game["cookies"] = 0

                        # Successful deliveries use the bonus sound.
                        play_sound(bonus_sound)
                    else:
                        # A partial rooftop landing is a house crash.
                        game["crashes"] += 1
                        game["score"] = max(0, game["score"] - 30)
                        game["house_hit_cooldown"] = 40
                        game["vertical_speed"] = -3.5
                        play_sound(crash_sound)

                        if game["crashes"] >= CRASH_LIMIT:
                            state = "gameover"
                            if music_loaded:
                                pygame.mixer.music.stop()

                # Hitting the house body also counts as a crash.
                house_body = pygame.Rect(
                    round(house["x"]),
                    round(house["y"]),
                    house["w"],
                    house["h"],
                )

                if (
                    not landing_contact
                    and not house["delivered"]
                    and game["house_hit_cooldown"] == 0
                    and player.colliderect(house_body)
                ):
                    game["score"] = max(0, game["score"] - 30)
                    game["crashes"] += 1
                    game["house_hit_cooldown"] = 40
                    game["vertical_speed"] = -3.5
                    player.x -= 10
                    play_sound(crash_sound)

                    if game["crashes"] >= CRASH_LIMIT:
                        state = "gameover"
                        if music_loaded:
                            pygame.mixer.music.stop()

            # Collect milk and cookies; they score when you land.
            for bonus in game["bonuses"][:]:
                draw_bonus(screen, bonus)

                if player.colliderect(object_rect(bonus)):
                    if bonus["kind"] == "milk":
                        game["milk"] += 1
                    else:
                        game["cookies"] += 1

                    play_sound(bonus_sound)
                    game["bonuses"].remove(bonus)

            # Remove objects that have moved offscreen.
            for collection_name in ("houses", "clouds", "planes", "bonuses"):
                game[collection_name] = [
                    obj for obj in game[collection_name]
                    if obj["x"] > -180
                ]

            if game["house_hit_cooldown"] > 0:
                game["house_hit_cooldown"] -= 1

            draw_sleigh(screen, player)

            # Heads-up display
            draw_text(screen, font, f"Score: {game['score']}", 18, 14, GOLD)
            draw_text(
                screen,
                font,
                f"Deliveries: {game['deliveries']}",
                18,
                44,
            )
            draw_text(
                screen,
                font,
                f"Milk: {game['milk']}  Cookies: {game['cookies']}",
                18,
                74,
            )
            draw_text(
                screen,
                font,
                f"Level {level}: {LEVEL_NAMES[level - 1]}",
                18,
                104,
                PALE_BLUE,
            )
            draw_text(
                screen,
                small_font,
                f"Cloud: -15   Crashes: {game['crashes']}/{CRASH_LIMIT}",
                330,
                15,
            )

        else:  # Game-over screen after ten house crashes
            draw_text(screen, big_font, "Sleigh crash!", 345, 150, RED)
            draw_text(
                screen,
                font,
                f"Final score: {game['score']}",
                395,
                235,
                GOLD,
            )
            draw_text(
                screen,
                font,
                f"Rooftop deliveries: {game['deliveries']}",
                355,
                275,
            )
            draw_text(
                screen,
                font,
                f"Crashes: {game['crashes']}/{CRASH_LIMIT}",
                395,
                310,
                PALE_BLUE,
            )
            draw_text(
                screen,
                font,
                "Press R to fly again.",
                385,
                350,
                PALE_BLUE,
            )

        pygame.display.flip()
        await asyncio.sleep(0)

    if music_loaded:
        pygame.mixer.music.stop()

    pygame.quit()


asyncio.run(main())

